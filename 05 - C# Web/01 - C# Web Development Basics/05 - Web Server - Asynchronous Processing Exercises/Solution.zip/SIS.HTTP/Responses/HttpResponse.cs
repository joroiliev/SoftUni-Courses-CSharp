﻿namespace SIS.HTTP.Responses
{
    using System.Linq;
    using System.Text;
    using SIS.HTTP.Common;
    using SIS.HTTP.Enums;
    using SIS.HTTP.Extensions;
    using SIS.HTTP.Headers;

    public class HttpResponse : IHttpResponse
    {
        public HttpResponse() { }

        public HttpResponse(HttpResponseStatusCode statusCode)
        {
            this.Headers = new HttpHeaderCollection();
            this.Content = new byte[0];
            this.StatusCode = statusCode;
        }

        public HttpResponseStatusCode StatusCode { get; set; }
        public IHttpHeaderCollection Headers { get; private set; }
        public byte[] Content { get; set; }

        public void AddHeader(HttpHeader header)
        {
            this.Headers.Add(header);
        }

        public byte[] GetBytes()
        {
            return Encoding.UTF8.GetBytes(this.ToString()).Concat(this.Content).ToArray();
        }

        public override string ToString()
        {
            StringBuilder result = new StringBuilder();

            result
                .Append($"{GlobalConstraints.HttpOneProtocolFragment} {this.StatusCode.GetResponseLine()}").Append(GlobalConstraints.HttpNewLine)
                .Append(this.Headers).Append(GlobalConstraints.HttpNewLine)
                .Append(GlobalConstraints.HttpNewLine);

            return result.ToString();
        }
    }
}
